Imagine you're a server and you're asked to get the stock price for three tickers

AMZN, GOOG, ORCL

Do you have the results yet?

Are you done?

What's taking you time?

What if you run into errors?

Are you giving one set of value or are you ready to stream values as they change?

