To try any of these examples, cd to the corresponding directory,
then type

npm install

Then type

npm start

After seeing the code running, take a look at the code and the HTML file to learn about the functions/API, etc. Then change the code, break it, put it back together, have fun!
