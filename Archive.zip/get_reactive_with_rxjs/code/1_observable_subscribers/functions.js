var isPrime = function(number) {
  for(var i = 2; i < number; i++) {
    if(number % i === 0) return false;
  }                                  
  
  return true;
} 

var primes = Rx.Observable.create(function(observer) {
  var count = 1;
  while(count < 100000) {
    if(isPrime(count))
      observer.next(count);
    count++;
  }
});

var subscribe = function() {
  primes.subscribe(function(prime) {
    console.log(prime);
  });
}