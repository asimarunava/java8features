public class SeaPlane extends Vehicle implements FastFly, Sail {
 public void cruise() { System.out.println("SeaPlane::cruise"); } 
}