public class Vehicle {
  public void turn() { System.out.println("Vehicle::turn"); }
}