package agiledeveloper;

import org.junit.jupiter.api.*;

import static agiledeveloper.Factorial.factorial;
import static org.junit.jupiter.api.Assertions.*;

public class FactorialTest {

  @BeforeEach
  void init() {
    System.out.println("init");
  }

  @AfterEach
  void cleanup() {
    System.out.println("after");
  }

  @Nested
  public class NegativeTests {
    @Test
    void factorialNegativeAssertThrows2() {
      Exception ex = assertThrows(IllegalArgumentException.class, () -> factorial(-1));

      assertEquals("Invalid parameter, should be zero or more", ex.getMessage());
    }
  }

  @Nested
  public class ZeroTest {
    @Test
    void factorial0() {
      assertEquals(1, factorial(0));
    }
  }

  @Nested
  public class PositiveTests {
    @Test
    void factorials() {
      assertAll("positive numbers",
                () -> assertEquals(1, factorial(1)),
                () -> assertEquals(2, factorial(2)));
    }
  }

}
