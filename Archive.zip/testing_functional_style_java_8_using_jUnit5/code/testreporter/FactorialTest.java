package agiledeveloper;

import org.junit.jupiter.api.*;

import java.util.HashMap;
import java.util.Map;

import static agiledeveloper.Factorial.factorial;
import static org.junit.jupiter.api.Assertions.*;

public class FactorialTest {
  @Test
  @DisplayName(("Some sample test"))
  @Tag("some tag")
  void sampleTest(TestReporter testReporter) {
    Map<String, String> map = new HashMap<>();

    map.put("1", "A");
    map.put("2", "B");

    testReporter.publishEntry(map);
  }
}