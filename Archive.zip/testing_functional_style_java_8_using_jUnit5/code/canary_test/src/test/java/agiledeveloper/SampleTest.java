package agiledeveloper;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class SampleTest {
  @Test
  void canaryTest() {
    assertTrue(true);
  }
}
