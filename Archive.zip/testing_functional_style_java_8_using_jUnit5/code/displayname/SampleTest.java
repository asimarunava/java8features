package agiledeveloper;

import org.junit.jupiter.api.*;

import static org.junit.jupiter.api.Assertions.assertTrue;

public class SampleTest {
  @Test
  @DisplayName("A canary test to verify the tool is setup properly")
  void canaryTest() {
    assertTrue(true);
  }
}
