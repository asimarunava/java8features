package agiledeveloper;

public class Factorial {
  public static int factorial(int number) {
    return 0;
  }
}
