package agiledeveloper;

import org.junit.jupiter.api.*;

import static agiledeveloper.Factorial.factorial;
import static org.junit.jupiter.api.Assertions.*;

public class FactorialTest {
//  @Test
//  void factorials() {
//    assertEquals(1, factorial(0)); //only this failure is reported
//    assertEquals(1, factorial(1));
//    assertEquals(2, factorial(2));
//  }

  @Test
  void factorials() {
    assertAll("check for multiple numbers",
              () -> assertEquals(1, factorial(0)),
              () -> assertEquals(1, factorial(1)),
              () -> assertEquals(2, factorial(2)));
  }
}
