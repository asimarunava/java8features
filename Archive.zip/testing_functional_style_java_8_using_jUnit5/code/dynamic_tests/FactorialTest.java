package agiledeveloper;

import org.junit.jupiter.api.*;


import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.*;
import java.util.stream.Stream;

import static agiledeveloper.Factorial.factorial;
import static org.junit.jupiter.api.Assertions.*;
import static org.junit.jupiter.api.DynamicTest.dynamicTest;

public class FactorialTest {
  @TestFactory
  Collection<DynamicTest> testFactor1() {
    return Arrays.asList(
        dynamicTest("test 1", () -> assertTrue(true)),
        dynamicTest("test 2", () -> assertEquals(1, 1)));
  }

  @TestFactory
  Iterable<DynamicTest> testFactor2() {
    return Arrays.asList(
        dynamicTest("test 3", () -> assertTrue(true)),
        dynamicTest("test 4", () -> assertEquals(1, 1)));
  }

  @TestFactory
  Iterator<DynamicTest> testFactor3() {
    return Arrays.asList(
        dynamicTest("test 5", () -> assertTrue(true)),
        dynamicTest("test 6", () -> assertEquals(1, 1))).iterator();
  }

  @TestFactory
  Stream<DynamicTest> testFactor4() {
    return Arrays.asList(
        dynamicTest("test 7", () -> assertTrue(true)),
        dynamicTest("test 8", () -> assertEquals(1, 1))).stream();
  }

  @TestFactory
  Stream<DynamicTest> testFactory5() {
    Map<Integer, Integer> factorials = new HashMap<>();
    factorials.put(0, 1);
    factorials.put(1, 1);
    factorials.put(2, 2);
    factorials.put(3, 6);
    factorials.put(5, 120);

    return factorials.keySet()
                     .stream()
                     .map(key -> dynamicTest("factorial for " + key, () -> assertEquals((int)factorials.get(key), factorial(key))));
  }

  public static DynamicTest split(String line) {
    String[] splitLine = line.split("-");

    return dynamicTest("factorial for " + splitLine[0], () -> assertEquals((int)(Integer.parseInt(splitLine[1])), factorial(Integer.parseInt(splitLine[0]))));
  }

  @TestFactory
  Stream<DynamicTest> testDriveFromFile() throws IOException {
    return Files.lines(Paths.get("factorials.dat"))
         .map(line -> split(line));
  }
}