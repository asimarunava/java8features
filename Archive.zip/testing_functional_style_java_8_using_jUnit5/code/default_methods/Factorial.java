package agiledeveloper;

import java.util.stream.IntStream;

public class Factorial {
  public static int factorial(int number) {
    if(number < 0) throw new IllegalArgumentException("Invalid parameter, should be zero or more");
    if(number == 0) return 1;

    return IntStream.rangeClosed(1, number)
                    .reduce(1, (product, e) -> product * e);
  }
}
