package agiledeveloper;

import org.junit.jupiter.api.*;

import static agiledeveloper.Factorial.factorial;
import static org.junit.jupiter.api.Assertions.*;

interface FactorialTest {
  @BeforeAll
  static void beforeAll() {
    System.out.println("before all...not used...");
  }

  @BeforeEach
  default void init() {
    System.out.println("init");
  }

  @AfterEach
  default void cleanup() {
    System.out.println("after");
  }

  @Test
  default void factorialNegativeAssertThrows2() {
    Exception ex = assertThrows(IllegalArgumentException.class, () -> factorial(-1));

    assertEquals("Invalid parameter, should be zero or more", ex.getMessage());
  }

  @Test
  default void factorial0() {
      assertEquals(1, factorial(0));
    }

  @Test
  default void factorials() {
    assertAll("positive numbers",
                () -> assertEquals(1, factorial(1)),
                () -> assertEquals(2, factorial(2)));
  }
}

class FactorialTests implements FactorialTest {

}