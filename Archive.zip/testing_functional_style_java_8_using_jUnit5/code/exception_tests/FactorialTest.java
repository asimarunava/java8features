package agiledeveloper;

import org.junit.jupiter.api.*;

import static agiledeveloper.Factorial.factorial;
import static org.junit.jupiter.api.Assertions.*;

public class FactorialTest {
  @Test
  void factorialOfNegativeVerbose() {
    try {
      factorial(-1);
      fail("Expected exception for negative argument");
    } catch(IllegalArgumentException ex) {
      assertTrue(true);
    }
  }

//  @Test(expected=IllegalArgumentException.class) //Not desirable, see <http://blog.agiledeveloper.com/2008/09/prefer-conciseness-over-terseness.html>.
//  void factorialOfNegativeJUnit4() {
//    try {
//      factorial(-1);
//      fail("Expected exception for negative argument");
//    } catch(IllegalArgumentException ex) {
//      assertTrue(true);
//    }
//  }

  @Test
  void factorialNegativeAssertThrows() {
    assertThrows(IllegalArgumentException.class, () -> factorial(-1));
  }

  @Test
  void factorialNegativeAssertThrows2() {
    Exception ex = assertThrows(IllegalArgumentException.class, () -> factorial(-1));

    assertEquals("Invalid parameter, should be zero or more", ex.getMessage());
  }
}
