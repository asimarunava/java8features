package agiledeveloper;

public class Factorial {
  public static int factorial(int number) {
    if(number < 0) throw new IllegalArgumentException("Invalid parameter, should be zero or more");
    return 0;
  }
}
