package agiledeveloper;

import org.junit.jupiter.api.*;

import static agiledeveloper.Factorial.factorial;
import static org.junit.jupiter.api.Assertions.*;

public class FactorialTest {
  @BeforeEach
  void init(TestInfo testInfo) {
    System.out.println("In BeforeEach...");
    System.out.println(testInfo.getDisplayName());
    System.out.println(testInfo.getTags());
    System.out.println(testInfo.getTestClass());
    System.out.println(testInfo.getTestMethod());
  }

  @Test
  @DisplayName(("Some sample test"))
  @Tag("some tag")
  void sampleTest(TestInfo testInfo) {
    System.out.println("In the test...");
    System.out.println(testInfo.getDisplayName());
    System.out.println(testInfo.getTags());
    System.out.println(testInfo.getTestClass());
    System.out.println(testInfo.getTestMethod());
  }
}