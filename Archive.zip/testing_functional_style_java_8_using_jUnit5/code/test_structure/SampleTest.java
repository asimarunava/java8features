package agiledeveloper;

import org.junit.jupiter.api.*;

import static org.junit.jupiter.api.Assertions.assertTrue;

public class SampleTest {
  @BeforeAll
  static void initBeforeAll() {
    System.out.println("before all tests");
  }

  @AfterAll
  static void afterAll() {
    System.out.println("\nafter all tests");
  }

  @BeforeEach
  void initBeforeEach() {
    System.out.println("before each test");
  }

  @AfterEach
  void afterEach() {
    System.out.println("after each test");
  }

  @Test
  void test1() {
    System.out.println("test 1");
  }

  @Test
  void test2() {
    System.out.println("test 2");
  }

  @Test
  @Disabled
  void test3() {
    System.out.println("disabled test");
  }
}
